package edu.neumont.csc150.c.models;

public interface Vehicle {
    double accelerate();
    double brake();
}
