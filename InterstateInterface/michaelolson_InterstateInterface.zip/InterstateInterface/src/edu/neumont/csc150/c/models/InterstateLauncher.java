package edu.neumont.csc150.c.models;

public class InterstateLauncher {
    public static void main(String[] args) {
        new InterstateController().run();
    }
}
