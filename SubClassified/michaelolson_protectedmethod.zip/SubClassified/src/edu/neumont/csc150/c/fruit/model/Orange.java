package edu.neumont.csc150.c.fruit.model;

public class Orange extends Fruit {
    private double peelThickness;

    public Orange() {}

    public Orange(double weight, String color, boolean isJuicy, int numOfSeeds) {
        setWeight(weight);
        setColor(color);
        setJuicy(isJuicy);
        setNumOfSeeds(numOfSeeds);
    }

    public double getPeelThickness() {
        return peelThickness;
    }

    public void setPeelThickness(double peelThickness) {
        this.peelThickness = peelThickness;
    }

    public void clean() {
        this.eliminateSeeds();
    }
}
