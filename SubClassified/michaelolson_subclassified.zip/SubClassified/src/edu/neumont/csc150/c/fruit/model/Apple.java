package edu.neumont.csc150.c.fruit.model;

public class Apple extends Fruit {
    private boolean isFiji;

    public Apple() {}

    public Apple(double weight, String color, boolean isJuicy, int numOfSeeds) {
        setWeight(weight);
        setColor(color);
        setJuicy(isJuicy);
        setNumOfSeeds(numOfSeeds);
    }

    public boolean getFiji() {
        return isFiji;
    }

    public void setFiji(boolean fiji) {
        isFiji = fiji;
    }
}
