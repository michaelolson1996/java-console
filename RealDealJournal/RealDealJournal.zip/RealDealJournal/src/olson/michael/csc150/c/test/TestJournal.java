package olson.michael.csc150.c.test;

import java.time.LocalDate;

public class TestJournal {
    public static void main(String[] args) {
        System.out.println(LocalDate.now());
    }
}
