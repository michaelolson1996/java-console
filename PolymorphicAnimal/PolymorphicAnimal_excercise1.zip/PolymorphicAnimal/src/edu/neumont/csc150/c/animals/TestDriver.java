package edu.neumont.csc150.c.animals;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TestDriver {

    private static Random gen = new Random();

    public static void main(String[] args) {

        List<Animal> animals = generateRandomAnimals(10000);

        for (Animal a : animals) {
            System.out.println(a.toString());
        }
    }

    private static List<Animal> generateRandomAnimals(int howMany) {
        List<Animal> results = new ArrayList<>();

        for (int i = 0; i < howMany; i++) {
            Animal r;

            if (gen.nextBoolean()) {
                r = new Snake();
            } else {
                r = new Giraffe();
            }
            r.setHasTail(gen.nextBoolean());
            r.setCountLimbs(gen.nextInt(4));
            r.setName("" + (char)(gen.nextInt(26) + 65)); // 65 - 90 inclusive
            results.add(r);
        }

        return results;
    }
}
