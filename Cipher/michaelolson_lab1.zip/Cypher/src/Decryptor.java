public class Decryptor {
    Type decryptionType;

    public Decryptor() {}

}
