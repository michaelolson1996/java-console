package Ciphers;

public class Grid {
    String[][] cipher;

    public void setCipher() {

    }

    public String[][] getCipher() { return this.cipher; }
}
