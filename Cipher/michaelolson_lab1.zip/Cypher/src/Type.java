public enum Type {
    CAESAR,
    VIGINERE,
    GRID
}