package edu.neumont.csc150.c.models;

public class Computer extends Player {

    public Computer() {}

    public Computer(String n) {
        super(n);
    }
}
