package edu.neumont.csc150.c.models;

public class Human extends Player {

    public Human() {}

    public Human(String n) {
        super(n);
    }
}
